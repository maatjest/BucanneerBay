function ships(){
    this.fleet = undefined;

    this.initialize = function(){
        this.fleet = {
            pirateFlagship: true,
            pirateCruiser: true,
            pirateFrigate1: true,
            pirateFrigate2: true,
            pirateScout: true
        };
    };

    //is this a valid ship?
    this.isShip = function(ship){
        
    }
}